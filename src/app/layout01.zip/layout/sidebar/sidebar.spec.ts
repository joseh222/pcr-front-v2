import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { vi } from 'vitest';

import { Sidebar } from './sidebar';

@Component({
    standalone: true,
    template: ''
})
class DashboardTestPage { }

describe('Sidebar', () => {
    let fixture: ComponentFixture<Sidebar>;
    let router: Router;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [Sidebar],
            providers: [
                provideRouter([
                    {
                        path: 'dashboard',
                        component: DashboardTestPage
                    }
                ])
            ]
        }).compileComponents();

        fixture = TestBed.createComponent(Sidebar);
        router = TestBed.inject(Router);

        fixture.detectChanges();
    });

    it('should render the configured navigation items', () => {
        const dashboard = fixture.nativeElement.querySelector(
            '[data-testid="nav-dashboard"]'
        ) as HTMLAnchorElement;

        expect(dashboard).toBeTruthy();
        expect(dashboard.textContent).toContain('Dashboard');
        expect(dashboard.getAttribute('href')).toBe('/dashboard');
    });

    it('should mark the current route as active', async () => {
        await router.navigateByUrl('/dashboard');
        await fixture.whenStable();
        fixture.detectChanges();

        const dashboard = fixture.nativeElement.querySelector(
            '[data-testid="nav-dashboard"]'
        ) as HTMLAnchorElement;

        expect(
            dashboard.classList.contains('sidebar-item-active')
        ).toBe(true);
    });

    it('should request sidebar close after navigation', () => {
        const closeSpy = vi.fn();
        fixture.componentInstance.closeRequested.subscribe(closeSpy);

        const dashboard = fixture.nativeElement.querySelector(
            '[data-testid="nav-dashboard"]'
        ) as HTMLAnchorElement;

        dashboard.click();

        expect(closeSpy).toHaveBeenCalledTimes(1);
    });
});