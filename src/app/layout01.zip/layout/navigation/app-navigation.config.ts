import { NavigationItem } from './navigation-item.model';

export const APP_NAVIGATION: readonly NavigationItem[] = [
    {
        id: 'dashboard',
        label: 'Dashboard',
        icon: 'dashboard',
        route: '/dashboard',
        exact: true
    }
];