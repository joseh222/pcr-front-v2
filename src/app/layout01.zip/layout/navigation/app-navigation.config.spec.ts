import { APP_NAVIGATION } from './app-navigation.config';

describe('APP_NAVIGATION', () => {
    it('should contain unique navigation identifiers', () => {
        const ids = APP_NAVIGATION.map(item => item.id);

        expect(new Set(ids).size).toBe(ids.length);
    });

    it('should contain valid navigation entries', () => {
        APP_NAVIGATION.forEach(item => {
            expect(item.id.trim()).not.toBe('');
            expect(item.label.trim()).not.toBe('');
            expect(item.icon.trim()).not.toBe('');
            expect(item.route.startsWith('/')).toBe(true);
        });
    });

    it('should contain the dashboard route', () => {
        expect(APP_NAVIGATION).toContainEqual({
            id: 'dashboard',
            label: 'Dashboard',
            icon: 'dashboard',
            route: '/dashboard',
            exact: true
        });
    });
});